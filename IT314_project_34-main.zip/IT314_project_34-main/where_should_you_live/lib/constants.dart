import 'package:flutter/material.dart';

class Constants {
  static const Color appPurpleColor = Color.fromRGBO(29, 9, 93, 1.0);
  static const Color appLightPurpleColor = Color.fromRGBO(232, 221, 252, 1.0);
}