//Onboarding Text

const String tOnboardingTitle1 = 'Welcome to "Where Should You Live?" ';
const String tOnboardingTitle2 =
    'Now your dream home is just a few clicks away';
const String tOnboardingTitle3 = 'The best place can be yours ';

const String tOnboardingSubTitle1 = 'It will help you find your dream place.';
const String tOnboardingSubTitle2 = 'Now find the place that best suits you';
const String tOnboardingSubTitle3 = 'Log in to find out ';

//Onboarding Counter Text
const String tOnboardingCounterText1 = '1/3';
const String tOnboardingCounterText2 = '2/3';
const String tOnboardingCounterText3 = '3/3';
