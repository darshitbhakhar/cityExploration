# GUI Testing

All the Webpages in the Neighborhood Recommendation System

GUI Testing using Selenium IDE

1.Task 1 - Sign up the new user and saved his/her preferences 

2.Task 2 - On boarding to Log In

3.Task 3 - Sign In using google account

4.Task 4 -Forgot Password functionality 

5.Task 5 -From Home page Edit profile and Wishlist 

6.Task 6 -From Home page Edit preferences and save Neighbourhood

7.Task 7 -Search using fillter and rate a city
