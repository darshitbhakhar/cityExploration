const String tOnBoardingImage1 = 'assets/images/on_boarding_images/onboarding_1.png';
const String tOnBoardingImage2 = 'assets/images/on_boarding_images/onboarding_2.png';
const String tOnboardingImage3 = 'assets/images/on_boarding_images/onboarding_3.png';