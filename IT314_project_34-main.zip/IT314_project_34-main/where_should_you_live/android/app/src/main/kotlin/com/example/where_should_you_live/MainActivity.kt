package com.example.where_should_you_live

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
